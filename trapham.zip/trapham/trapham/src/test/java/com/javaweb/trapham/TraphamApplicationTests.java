package com.javaweb.trapham;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TraphamApplicationTests {

	@Test
	void contextLoads() {
	}

}
